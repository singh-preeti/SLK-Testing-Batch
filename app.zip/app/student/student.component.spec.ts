import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { StudentComponent } from './student.component';
import { StudentService } from '../student.service';
import { of } from 'rxjs';
import { By } from '@angular/platform-browser';
describe('StudentComponent', () => {
  let component: StudentComponent;
  let fixture: ComponentFixture<StudentComponent>;
  ComponentFixture<StudentComponent>;
  let h1: HTMLElement;
  let deb : DebugElement;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    deb = fixture.debugElement;
    h1 = fixture.nativeElement.querySelector('h1');
  });
  

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('spy On Method', () => {
    spyOn(component, 'calculate');
    component.saveData();
    expect(component.calculate).toHaveBeenCalled();
  });

  it('spy On Method - 1', () => {
    spyOn(component, 'calculate').and.returnValues(10, 20);
    let result = component.studentResult();
    expect(result).toEqual("Fail");
  });

  it('spy On Method - 2', () => {
    let service = fixture.debugElement.injector.get(StudentService);
    spyOn(service, "SaveDetails").and.callFake(() => {
      return of({
        "result1": 200
      })
    });

    spyOn(component, "SaveDataIntoConsole").and.stub();
    component.saveData();
    expect(component.result).toEqual({
      "result1": 200
    })
  });

  it('Verify the h1 element value',() =>{
    component.StudentSchoolResult();
    fixture.detectChanges() // to identify that purticular dom value changes 
    expect(h1.textContent).toBe(component.studentResult);
  })

  it('increase count click', () => {
     
    const h1 = deb.query(By.css('h1'));
    const btn = deb.query(By.css('#btnincreaseNumber'));

    btn.triggerEventHandler('click', {});
    fixture.detectChanges();

    expect(component.countNumber).toEqual(parseInt( h1.nativeElement.innerText));

  });

  it("call private method", () => {
    component["ShowName"]();
    expect(component["Name"]).toEqual("Sla Testing!")
  });

  it("call private method - 1", () => {
    component["calculate"](10, 20);
    expect(component.sum).toEqual(30);
  });

  it("SpyOn private method", () => {
    let SpyOn = spyOn<any>(component,"ShowName");
    component["ShowName"]();
    expect(SpyOn).toHaveBeenCalled();
  });

  it("SpyOn private method - 1", () => {
    let SpyOn = spyOn<any>(component,"calculate");
    component["calculate"](10, 20);
    expect(SpyOn).toHaveBeenCalled();
  });
});
