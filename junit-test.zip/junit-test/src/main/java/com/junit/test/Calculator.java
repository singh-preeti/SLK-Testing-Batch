package com.junit.test;

public class Calculator {
	 public int add(int a,int b)
	 {
		 int c;
		 c= a+b;
		 return c;
	 }
    public int sub(int a, int b)
    {
    	int c;
    	c=a-b;
    	return c;
    }
}
