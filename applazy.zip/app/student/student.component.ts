import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  title = "AngularUnitTestApp";
  private sum = 0;
  result: any;
  studentResult:any;
  countNumber: any;
  //private Name: any;

  Name = "The Dotnet office";
  num1 = 100;
  num2 = 20;


  type = "number";
  placeholder = "givennumber";
  userReadonly = false;


  num = 20;
  redColor = 'font-red';
  blueColor = 'font=blue';
// Attribute Binding

  pageHeader:string = 'Student information';
  FirstName: string = 'Jasmin';
  LastName:string='Test';
  Branch:string='IT';
  Mobile:number=1234567890;
  Gender:string='Male';
  Age:number=25;

  ColumnSpan =2;

  arialable = "NewAriaLable"

  // Event Binding

  label: string = "Python";

  //WhenStable 

  studentName:string=" "
  constructor(public services: StudentService) { }

  ngOnInit(): void {
  }
  
  setName(){
    this.studentName = "Angular Unit Testing!";
  }
  
  button1Click() {
    this.label = "Python office";

  }

  button2Click() {
    this.label = "label value change on button2";

  }
  onChangeInput() {
    this.label = "onChangeInput label value change";

  }

  onChangeLabelInput(event: any) {
    this.label = event.target.value;
  }


private  calculate(num1: number, num2: number) {
    this.sum = num1 + num2;
    return this.sum;
  }

  saveData() {
    let info = {
      sumVal: this.calculate(5, 5),
      name: "SLA testing App!"
    };
    //this.SaveDataIntoConsole(info);
    this.services.SaveDetails(info).subscribe(
      response => {
      this.result = response;
    })
  };

  StudentSchoolResult(){
    if(this.calculate(10,20) >= 40)
    {
      this.studentResult =  "Pass";
      return this.studentResult;
    }
    else
    {
      this.studentResult = "Fail";
      return this.studentResult ;
    }
  }

  ShowMessage(Msg: string): string {
    return Msg;
  }

  SaveDataIntoConsole(info: any) {

    console.log(info);
  }
  increseNumber() {
    this.countNumber = this.countNumber + 1;
  }

  decreaseNumber() {
    this.countNumber = this.countNumber - 1;
  }
  private ShowName() {
    this.Name = "Sla Testing!";
  }


}
