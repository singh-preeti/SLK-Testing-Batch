import { ComponentFixture, TestBed, fakeAsync, tick, waitForAsync } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { StudentComponent } from './student.component';
import { StudentService } from '../student.service';
import { of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from '../app-routing.module';
describe('StudentComponent', () => {
  let component: StudentComponent;
  let fixture: ComponentFixture<StudentComponent>;
  //ComponentFixture<StudentComponent>;
  let h1: HTMLElement;
  let deb : DebugElement;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentComponent ],
      providers: [StudentService],
      imports: [HttpClientModule,AppRoutingModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    deb = fixture.debugElement;
    h1 = fixture.nativeElement.querySelector('h1');
  });
  

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('spy On Method', () => {
    spyOn(component, 'calculate');
    component.saveData();
    expect(component.calculate).toHaveBeenCalled();
  });

  it('spy On Method - 1', () => {
    spyOn(component, 'calculate').and.returnValues(10, 20);
    let result = component.StudentSchoolResult();
    expect(result).toEqual("Fail");
  });

  // it('spy On Method - 2', () => {
  //   let service = fixture.debugElement.injector.get(StudentService);
  //   spyOn(service, "SaveDetails").and.callFake(() => {
  //     return of({
  //       "result1": 200
  //     })
    //});

  //   spyOn(component, "SaveDataIntoConsole").and.stub();
  //   component.saveData();
  //   expect(component.result).toEqual({
  //     "result1": 200
  //   })
  // });

  it('Verify the h1 element value',() =>{
    component.StudentSchoolResult();
    fixture.detectChanges() // to identify that purticular dom value changes 
    expect(h1.textContent).toBe(component.studentResult);
  })

  // it('increase count click', () => {
     
  //   const h1 = deb.query(By.css('h1'));
  //   const btn = deb.query(By.css('#btnincreaseNumber'));

  //   btn.triggerEventHandler('click', {});
  //   fixture.detectChanges();

  //   expect(component.countNumber).toEqual(parseInt( h1.nativeElement.innerText));

  // });

  it("call private method", () => {
    component["ShowName"]();
    expect(component["Name"]).toEqual("Sla Testing!")
  });

  it("call private method - 1", () => {
    component["calculate"](10, 20);
    expect(component["sum"]).toEqual(30);
  });

  it("SpyOn private method", () => {
    let SpyOn = spyOn<any>(component,"ShowName");
    component["ShowName"]();
    expect(SpyOn).toHaveBeenCalled();
  });

  it("SpyOn private method - 1", () => {
    let SpyOn = spyOn<any>(component,"calculate");
    component["calculate"](10, 20);
    expect(SpyOn).toHaveBeenCalled();
  });

  it("interpolation test", () => {
 
    const name : HTMLElement = fixture.debugElement.nativeElement.querySelector('#name');
    expect(name.innerHTML).toEqual(component.Name);

    component.Name = "name-updated";
    fixture.detectChanges();
    expect(name.innerHTML).toEqual(component.Name);
  });

  it("interpolation test for textbox", () => {
 
    const inputelement : HTMLInputElement = fixture.debugElement.nativeElement.querySelector('#userName');
    expect(inputelement.type).toEqual(component.type);

    component.type = "text";
    fixture.detectChanges();
    expect(inputelement.type).toEqual(component.type);

    expect(inputelement.readOnly).toBeFalsy();
  });

  






  
  it("ngClass test case for parghraph", () => {
 
    const elemtnt  = fixture.debugElement.nativeElement.querySelector('#header');
    expect(elemtnt.getAttribute('class')).toContain('font-red');

    
  });

  it("ngClass test case for h1", () => {
 
    const elemtnt  = fixture.debugElement.nativeElement.querySelector('#header1');
    expect(elemtnt.getAttribute('class')).toContain('font-blue');
    
    component.num = 5;
    fixture.detectChanges();
    
    expect(elemtnt.getAttribute('class')).toContain('font-red');

    
  });

  it("ngStyle test case for parghraph  - 2", () => {
 
    const elemtnt  = fixture.debugElement.nativeElement.querySelector('#header2');
    expect(elemtnt.getAttribute('style')).toContain('color: black');

    
  });


// Attribute Binding

  it("table colspan attribute test case", () => {
 
    const elemtnt  = fixture.debugElement.nativeElement.querySelector('#colId');
    expect(elemtnt.getAttribute('colspan')).toEqual(component.ColumnSpan.toString());
    
  });

  it("button  attribute test case", () => {
 
    const elemtnt  = fixture.debugElement.nativeElement.querySelector('#buttonid');
    expect(elemtnt.getAttribute('aria-label')).toEqual(component.arialable.toString());

    
  });



  //Event Binding



  it("button 1", () => {
 
    const elemtnt : HTMLButtonElement = fixture.debugElement.nativeElement.querySelector('#button1');
    expect(component.label).toEqual("Python");

    elemtnt.click();
    fixture.detectChanges();
    expect(component.label).toEqual("Python office");
    
  });

  it("button 2", () => {
 
    const elemtnt : HTMLButtonElement = fixture.debugElement.nativeElement.querySelector('#button2');
    expect(component.label).toEqual("Python");

    elemtnt.click();
    fixture.detectChanges();
    expect(component.label).toEqual("label value change on button2");
    
  });
  
  it("textbox 1", () => {
 
    const elemtnt : HTMLInputElement = fixture.debugElement.nativeElement.querySelector('#textbox1');
    expect(component.label).toEqual("Python");

    elemtnt.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(component.label).toEqual("onChangeInput label value change");
    
  });

  it("textbox 2", () => {
 
    const elemtnt : HTMLInputElement = fixture.debugElement.nativeElement.querySelector('#textbox2');
    expect(component.label).toEqual("Python");

    elemtnt.value = "Python - updated"
    elemtnt.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    expect(component.label).toEqual("Python - updated");
    
  });

  // WhenStable

  it("set studentName from component", (done) => {

    component.studentName = 'dotnetoffice_updated';
    fixture.detectChanges();

    fixture.whenStable().then(() => {
      const elemtnt: HTMLInputElement = fixture.debugElement.nativeElement.querySelector('#name');
      expect(elemtnt.value).toEqual('dotnetoffice_updated');
      done();
    })
    

  });

  it("set textbox  value", (done) => {

    fixture.detectChanges();

    fixture.whenStable().then(() => {
      const elemtnt: HTMLInputElement = fixture.debugElement.nativeElement.querySelector('#name');

      elemtnt.value = "textbox updated";
      elemtnt.dispatchEvent(new Event('input'));
      expect(elemtnt.value).toEqual(component.studentName);
      done();
    });
  });

    it("button click test case", (done) => {

      fixture.detectChanges();
      const elemtnt: HTMLButtonElement = fixture.debugElement.nativeElement.querySelector('#button1');
      

      fixture.whenStable().then(() => {
        elemtnt.click();
     
        expect(component.studentName).toEqual("Angular Unit Testing!");
        fixture.detectChanges();
        fixture.whenStable().then(()=>{
          const elemtnt: HTMLInputElement = fixture.debugElement.nativeElement.querySelector('#name');
          expect(elemtnt.value).toEqual("Angular Unit Testing!");
          done();
        })
       
       
        
      });

  });

   
  it("set studentName from component", waitForAsync(() => {

    component.studentName = 'dotnetoffice_updated';
    fixture.detectChanges();

    fixture.whenStable().then(() => {
      const elemtnt: HTMLInputElement = fixture.debugElement.nativeElement.querySelector('#name');
      expect(elemtnt.value).toEqual('dotnetoffice_updated');
     
    })

    
  }));

  it("set studentName from component with fakeAsync", fakeAsync(() => {

    component.studentName = 'dotnetoffice_updated';
    fixture.detectChanges();

    tick();
    //fixture.whenStable().then(() => {
      const elemtnt: HTMLInputElement = fixture.debugElement.nativeElement.querySelector('#name');
      expect(elemtnt.value).toEqual('dotnetoffice_updated');
     
   // })

    
  }));



});
